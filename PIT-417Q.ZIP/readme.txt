���                                                               ���
���                                                               ���
��� Tribute to James Royal Berry                                  ���
��� The Pit 4.17 patch and mod                                    ���
��� by github @rambkk ram@pluslab.com                             ���
��� 2022-May-28                                                   ���
���                                                               ���
���                                                               ���

Tribute to James Royal Berry for creating the amazing world.
Thanks to all BBS SysOps and users from old days till now.
Kindly drop an email to say hi so I can know my work is useful.
Also, if you are running a BBS, do let me know.

Tribute by Michael B. Duff
https://michaelduff.net/2011/06/02/a-tribute-to-james-royal-berry-1967-1999/

DISCLAIMER: This is provided AS-IS, without any guarantee.

This patch includes fixing of level limit check. 
The higher level calculation (>10) code, I have written
the level up code for the higher levels in Assembly
as this code is missing in the public demo version.

This should work well for PIT.EXE and EGAPIT.EXE 
for playing locally and via a BBS.

VERSION q update 2022-05-29:
Players can now exceed level 499 to end the game in both
text and while using graphical interface. 
However, the player cannot view list of IMMORTALS via the 
graphical PTERM.EXE.


FIXED (old issue): 
There is a small problem when using the PTERM.EXE and exceeding 
level 499, the game does not end properly. There seem to be
some server side registration check.

If TSR is prefered to patching, drop me an email.


File list:
UNP.EXE      - EXE unpacker
PATPIT.EXE   - PIT.EXE patcher
PATEGA.EXE   - EGAPIT.EXE patcher
PATPTERM.EXE - PTERM.EXE patcher

The Pit v4.17 software and The Pit graphical download:
https://breakintochat.com/wiki/The_Pit
 
------------------
Steps in patching:
------------------
-Download The Pit v4.17 at https://breakintochat.com/wiki/The_Pit
-Backup all EXE files
-go to the directory with the appropriate file to patch
-run unpack and patch: 

(for the pit main directory)
UNP PIT.EXE
UNP EGAPIT.EXE
PATPIT
PATEGA

(for the pterm client)
UNP PTERM.EXE
PATPTERM




